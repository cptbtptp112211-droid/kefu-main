import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";
import { createRequire } from "module";

const require = createRequire(import.meta.url);
const Database = require("better-sqlite3");

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize SQLite Database
const db = new Database("chat.db");

// Create Tables
db.exec(`
  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
  );

  CREATE TABLE IF NOT EXISTS conversations (
    id TEXT PRIMARY KEY,
    customerName TEXT,
    ip TEXT,
    status TEXT DEFAULT 'open',
    lastMessage TEXT,
    unreadCount INTEGER DEFAULT 0,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    conversationId TEXT,
    text TEXT,
    imageUrl TEXT,
    senderType TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(conversationId) REFERENCES conversations(id)
  );

  CREATE TABLE IF NOT EXISTS admins (
    username TEXT PRIMARY KEY,
    password TEXT
  );
`);

// Seed default admin if not exists
const adminExists = db.prepare("SELECT * FROM admins WHERE username = ?").get("admin");
if (!adminExists) {
  db.prepare("INSERT INTO admins (username, password) VALUES (?, ?)").run("admin", "123456");
}

// Seed default settings if not exists
const settingsExists = db.prepare("SELECT * FROM settings WHERE key = ?").get("auto-reply");
if (!settingsExists) {
  const defaultSettings = {
    autoReplies: [{ text: "您好！欢迎咨询，请问有什么可以帮您？" }],
    enabled: true,
    adminNotificationSoundUrl: "https://assets.mixkit.co/active_storage/sfx/2358/2358-preview.mp3",
    customerNotificationSoundUrl: "https://assets.mixkit.co/active_storage/sfx/2358/2358-preview.mp3",
    avatarUrl: "",
    serviceName: "在线客服"
  };
  db.prepare("INSERT INTO settings (key, value) VALUES (?, ?)").run("auto-reply", JSON.stringify(defaultSettings));
}

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: { origin: "*", methods: ["GET", "POST"] }
  });

  const PORT = Number(process.env.PORT) || 10000;
  app.use(express.json({ limit: '10mb' }));

  // Socket.io logic
  io.on("connection", (socket) => {
    socket.on("join_conversation", (conversationId) => {
      socket.join(conversationId);
    });

    socket.on("join_admin", () => {
      socket.join("admin_room");
    });
  });

  // API Routes
  app.post("/api/login", (req, res) => {
    const { username, password } = req.body;
    const admin = db.prepare("SELECT * FROM admins WHERE username = ? AND password = ?").get(username, password);
    if (admin) {
      res.json({ success: true, username: admin.username });
    } else {
      res.status(401).json({ error: "用户名或密码错误" });
    }
  });

  app.post("/api/admin/update", (req, res) => {
    const { oldUsername, newUsername, newPassword } = req.body;
    try {
      if (newUsername && newPassword) {
        db.prepare("UPDATE admins SET username = ?, password = ? WHERE username = ?").run(newUsername, newPassword, oldUsername);
      } else if (newUsername) {
        db.prepare("UPDATE admins SET username = ? WHERE username = ?").run(newUsername, oldUsername);
      } else if (newPassword) {
        db.prepare("UPDATE admins SET password = ? WHERE username = ?").run(newPassword, oldUsername);
      }
      res.json({ success: true });
    } catch (e) {
      res.status(500).json({ error: "修改失败" });
    }
  });

  app.get("/api/settings", (req, res) => {
    const row = db.prepare("SELECT value FROM settings WHERE key = ?").get("auto-reply") as any;
    res.json(JSON.parse(row.value));
  });

  app.post("/api/settings", (req, res) => {
    db.prepare("UPDATE settings SET value = ? WHERE key = ?").run(JSON.stringify(req.body), "auto-reply");
    io.emit("settings_update", req.body);
    res.json({ success: true });
  });

  app.get("/api/conversations", (req, res) => {
    const rows = db.prepare("SELECT * FROM conversations ORDER BY updatedAt DESC").all();
    res.json(rows);
  });

  app.post("/api/conversations", (req, res) => {
    const { customerName, ip } = req.body;
    const id = Math.random().toString(36).substring(2, 15);
    db.prepare("INSERT INTO conversations (id, customerName, ip) VALUES (?, ?, ?)").run(id, customerName, ip);
    
    // Check for auto-reply settings to send welcome messages
    const settingsRow = db.prepare("SELECT value FROM settings WHERE key = ?").get("auto-reply") as any;
    if (settingsRow) {
      const settings = JSON.parse(settingsRow.value);
      if (settings.enabled && settings.autoReplies && settings.autoReplies.length > 0) {
        let lastMsgText = "";
        for (const welcomeMessage of settings.autoReplies) {
          if (welcomeMessage.text || welcomeMessage.imageUrl) {
            const info = db.prepare("INSERT INTO messages (conversationId, text, imageUrl, senderType) VALUES (?, ?, ?, ?)").run(
              id, 
              welcomeMessage.text || "", 
              welcomeMessage.imageUrl || "", 
              'admin'
            );
            
            const message = {
              id: info.lastInsertRowid,
              conversationId: id,
              text: welcomeMessage.text || "",
              imageUrl: welcomeMessage.imageUrl || "",
              senderType: 'admin',
              timestamp: new Date().toISOString()
            };
            
            // Broadcast to admin room so they see the welcome message in the log
            io.to("admin_room").emit("new_message", message);
            
            lastMsgText = welcomeMessage.text || "[图片]";
          }
        }
        if (lastMsgText) {
          // Update conversation last message
          db.prepare("UPDATE conversations SET lastMessage = ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?").run(
            lastMsgText, 
            id
          );
        }
      }
    }

    // Notify admin
    const conversations = db.prepare("SELECT * FROM conversations ORDER BY updatedAt DESC").all();
    io.to("admin_room").emit("conversations_update", conversations);
    
    res.json({ id });
  });

  app.get("/api/messages/:conversationId", (req, res) => {
    const { conversationId } = req.params;
    // Reset unread count when messages are fetched (admin viewing)
    db.prepare("UPDATE conversations SET unreadCount = 0 WHERE id = ?").run(conversationId);
    
    // Notify admin list to update counts
    const conversations = db.prepare("SELECT * FROM conversations ORDER BY updatedAt DESC").all();
    io.to("admin_room").emit("conversations_update", conversations);

    const rows = db.prepare("SELECT * FROM messages WHERE conversationId = ? ORDER BY timestamp ASC").all(conversationId);
    res.json(rows);
  });

  app.post("/api/messages", (req, res) => {
    const { conversationId, text, senderType, imageUrl } = req.body;
    
    // Ensure conversation exists (especially after a clear-history)
    const conversation = db.prepare("SELECT * FROM conversations WHERE id = ?").get(conversationId);
    if (!conversation && senderType === 'customer') {
      const ip = (req.headers['x-forwarded-for'] as string || req.socket.remoteAddress || 'Unknown').split(',')[0].trim();
      db.prepare("INSERT INTO conversations (id, customerName, ip, lastMessage) VALUES (?, ?, ?, ?)").run(
        conversationId, 
        `访客 (已重置)`, 
        ip,
        text || "[图片]"
      );
    }

    const info = db.prepare("INSERT INTO messages (conversationId, text, senderType, imageUrl) VALUES (?, ?, ?, ?)").run(conversationId, text, senderType, imageUrl);
    
    const message = {
      id: info.lastInsertRowid,
      conversationId,
      text,
      senderType,
      imageUrl,
      timestamp: new Date().toISOString()
    };

    // Update conversation last message and increment unread if from customer
    if (senderType === 'customer') {
      db.prepare("UPDATE conversations SET lastMessage = ?, unreadCount = unreadCount + 1, updatedAt = CURRENT_TIMESTAMP WHERE id = ?").run(text || "[图片]", conversationId);
      
      // Auto-reply logic for customer messages
      const settingsRow = db.prepare("SELECT value FROM settings WHERE key = ?").get("auto-reply") as any;
      if (settingsRow) {
        const settings = JSON.parse(settingsRow.value);
        // If enabled and it's the first message from customer (or we want to send it anyway)
        // Here we check if there are no other admin messages yet to avoid spamming
        const adminMessages = db.prepare("SELECT COUNT(*) as count FROM messages WHERE conversationId = ? AND senderType = 'admin'").get(conversationId) as any;
        
        if (settings.enabled && settings.autoReplies && settings.autoReplies.length > 0 && adminMessages.count === 0) {
          // Send the first auto-reply as a welcome/initial response
          const reply = settings.autoReplies[0];
          if (reply.text || reply.imageUrl) {
            const replyInfo = db.prepare("INSERT INTO messages (conversationId, text, imageUrl, senderType) VALUES (?, ?, ?, ?)").run(
              conversationId, 
              reply.text || "", 
              reply.imageUrl || "", 
              'admin'
            );
            
            const replyMessage = {
              id: replyInfo.lastInsertRowid,
              conversationId,
              text: reply.text,
              imageUrl: reply.imageUrl,
              senderType: 'admin',
              timestamp: new Date().toISOString()
            };
            
            // Broadcast auto-reply
            setTimeout(() => {
              io.to(conversationId).emit("new_message", replyMessage);
              io.to("admin_room").emit("new_message", replyMessage);
              
              // Update conversation last message with the auto-reply
              db.prepare("UPDATE conversations SET lastMessage = ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?").run(
                reply.text || "[图片]", 
                conversationId
              );
              
              // Update admin list again
              const conversations = db.prepare("SELECT * FROM conversations ORDER BY updatedAt DESC").all();
              io.to("admin_room").emit("conversations_update", conversations);
            }, 500); // Small delay for natural feel
          }
        }
      }
    } else {
      db.prepare("UPDATE conversations SET lastMessage = ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?").run(text || "[图片]", conversationId);
    }

    // Broadcast
    io.to(conversationId).emit("new_message", message);
    io.to("admin_room").emit("new_message", message);
    
    // Update admin list
    const conversations = db.prepare("SELECT * FROM conversations ORDER BY updatedAt DESC").all();
    io.to("admin_room").emit("conversations_update", conversations);

    res.json(message);
  });

  app.post("/api/clear-history", (req, res) => {
    // 仅删除消息和会话，不触动 settings 表
    db.prepare("DELETE FROM messages").run();
    db.prepare("DELETE FROM conversations").run();
    // 广播清理信号
    io.emit("history_cleared");
    res.json({ success: true });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*all", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
